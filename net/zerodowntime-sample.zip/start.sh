cd /tmp

rm -rf zerodowntime-sample; true

git clone https://github.com/szimbaro/zerodowntime-sample.git

cd zerodowntime-sample

python -m SimpleHTTPServer 8080

#npm install

#nodejs app.js  